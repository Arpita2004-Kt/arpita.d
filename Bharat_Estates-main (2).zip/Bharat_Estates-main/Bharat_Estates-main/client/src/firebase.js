// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// // import { getAnalytics } from "firebase/analytics";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: import.meta.env.VITE_FIREBASE_API_KEY ,  
//   authDomain: "bharat-estate-24de0.firebaseapp.com",
//   projectId: "bharat-estate-24de0",
//   storageBucket: "bharat-estate-24de0.appspot.com",
//   messagingSenderId: "22971721886",
//   appId: "1:22971721886:web:37b04037d4c793c064338f",
//   measurementId: "G-G891SRYVWQ"
// };

// // Initialize Firebase
// export const app = initializeApp(firebaseConfig);
// // const analytics = getAnalytics(app);
// ------------------------------------------------------------------------------------------------------------------------------------


// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
//   authDomain: "bharat-estates-3720a.firebaseapp.com",
//   projectId: "bharat-estates-3720a",
//   storageBucket: "bharat-estates-3720a.appspot.com",
//   messagingSenderId: "564151105016",
//   appId: "1:564151105016:web:49859cce83ca5b2b2d520d"
// };

// // Initialize Firebase
// export const app = initializeApp(firebaseConfig);

//=========================================================================================================================================

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAyDvav4LEefUspFHGKGhxrTSHdKNZ0Vow",
  authDomain: "estate-project-b5b89.firebaseapp.com",
  projectId: "estate-project-b5b89",
  storageBucket: "estate-project-b5b89.appspot.com",
  messagingSenderId: "1017985299186",
  appId: "1:1017985299186:web:763c1c9699ae7af432d66b"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig); 